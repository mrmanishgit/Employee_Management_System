

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Database: `project3`
- CREATE USER EMPLOYEE IDENTIFIED BY 123;

User created.


-- --------------------------------------------------------

--
-- Table structure for table `account`
--

SQL> CREATE TABLE account (
  2    username VARCHAR2(20) NOT NULL,
  3    name VARCHAR2(25) NOT NULL,
  4    password VARCHAR2(25) NOT NULL,
  5    sec_q VARCHAR2(25) NOT NULL,
  6    sec_ans VARCHAR2(25) NOT NULL
  7  );

Table created.


--
-- Dumping data for table `account`
--

SQL> INSERT INTO account (username, name, password, sec_q, sec_ans)
  2  VALUES ('manish123', 'manish', '123', 'Your NickName?', '123');

1 row created.


-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

SQL> CREATE TABLE attendance (
  2    emp_id VARCHAR2(20) NOT NULL,
  3    first VARCHAR2(10) NOT NULL,
  4    second VARCHAR2(10) NOT NULL,
  5    "Date" VARCHAR2(30) NOT NULL
  6  );


--
-- Dumping data for table `attendance`
--

SQL> INSERT INTO attendance (emp_id, first, second, "Date")
  2  VALUES ('101', 'Present', 'Present', 'Fri Jun 23 10:27:07 IST 2024');


-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

SQL> CREATE TABLE employee (
  2    name VARCHAR2(25) NOT NULL,
  3    fname VARCHAR2(30) NOT NULL,
  4    age NUMBER(3) NOT NULL,
  5    dob DATE NOT NULL,
  6    address VARCHAR2(50) NOT NULL,
  7    phone NUMBER(10) NOT NULL,
  8    email VARCHAR2(30) NOT NULL,
  9    education VARCHAR2(15) NOT NULL,
 10    post VARCHAR2(15) NOT NULL,
 11    aadhar VARCHAR2(12) NOT NULL,
 12    emp_id NUMBER(5) NOT NULL
 13  );

--
-- Dumping data for table `employee`
--

SQL> INSERT INTO employee (name, fname, age, dob, address, phone, email, education, post, aadhar, emp_id)
  2  VALUES
  3  ('D sunil', 'D', 21, TO_DATE('2003-02-20', 'YYYY-MM-DD'),
  4  'odisha', 1234567890, 'sunil@gmail.com', 'B.tech', 'programer', '789654123654', 101);
SQL> INSERT INTO employee (name, fname, age, dob, address, phone, email, education, post, aadhar, emp_id)
  2  VALUES
  3  ('Prasad sahu', 'P', 21, TO_DATE('2003-04-12', 'YYYY-MM-DD'),
  4  'odisha', 1234567856, 'prasad@gmail.com', 'B.tech', 'Engineer', '789654123456', 102);

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

SQL> CREATE TABLE salary (
  2    id NUMBER(10) NOT NULL,
  3    hra NUMBER(12,2) NOT NULL,
  4    da NUMBER(12,2) NOT NULL,
  5    med NUMBER(12,2) NOT NULL,
  6    pf NUMBER(12,2) NOT NULL,
  7    basic_salary NUMBER(12,2) NOT NULL
  8  );

--
-- Dumping data for table `salary`
--

SQL> INSERT INTO salary (id, hra, da, med, pf, basic_salary)
  2  VALUES
  3  (101, 1000.00, 1000.00, 1555.00, 1000.00, 10000.00);

SQL> INSERT INTO salary (id, hra, da, med, pf, basic_salary)
  2  VALUES
  3  (102, 84584.00, 55468.00, 55.00, 5425.00, 5458.00);

COMMIT;
Commit complete.
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

 ------------------------ ------------------------------ ---------------------------------- ---------------------------------- -    -- ---- - --  -- -- -- -- -
SQL> SELECT*FROM ACCOUNT;

USERNAME             NAME                      PASSWORD
-------------------- ------------------------- -------------------------
SEC_Q                     SEC_ANS
------------------------- -------------------------
manish123            manish                    123
Your NickName?            123


SQL> SELECT*FROM ATTENDANCE;

EMP_ID               FIRST      SECOND     Date
-------------------- ---------- ---------- ------------------------------
101                  Present    Present    Fri Jun 23 10:27:07 IST 2024
102                  Present    Present    Fri Jun 23 10:27:07 IST 2024

SQL> SELECT*FROM EMPLOYEE;

NAME                      FNAME                                 AGE DOB
------------------------- ------------------------------ ---------- ---------
ADDRESS                                                 PHONE
-------------------------------------------------- ----------
EMAIL                          EDUCATION       POST            AADHAR
------------------------------ --------------- --------------- ------------
    EMP_ID
----------
D sunil                   D                                      21 20-FEB-03
odisha                                             1234567890
sunil@gmail.com                B.tech          programer       789654123654
       101


NAME                      FNAME                                 AGE DOB
------------------------- ------------------------------ ---------- ---------
ADDRESS                                                 PHONE
-------------------------------------------------- ----------
EMAIL                          EDUCATION       POST            AADHAR
------------------------------ --------------- --------------- ------------
    EMP_ID
----------
Prasad sahu               P                                      21 12-APR-03
odisha                                             1234567856
prasad@gmail.com               B.tech          Engineer        789654123456
       102


SQL> SELECT*FROM SALARY;

        ID        HRA         DA        MED         PF BASIC_SALARY
---------- ---------- ---------- ---------- ---------- ------------
       101       1000       1000       1555       1000        10000
       102      84584      55468         55       5425         5458

 
